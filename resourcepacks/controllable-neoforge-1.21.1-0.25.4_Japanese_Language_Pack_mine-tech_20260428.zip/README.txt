Original MOD: Controllable
Original Author: MrCrayfish
Copyright (c) 2025 MrCrayfish
Official Distribution: https://www.curseforge.com/minecraft/mc-mods/controllable
Official Repository: https://github.com/MrCrayfish/Controllable

--------------------------------------------------
Japanese Translation (Non-official) / 日本語化リソースパック (非公式)
Copyright (C) 2026 Mine-Tech
Website: https://www.mine-blog.tech/
Modification Date: 2026-04-28
Modified Content: Translated language files (added/modified ja_jp.json based on en_us.json)
--------------------------------------------------

License / ライセンス:
This resource pack is a derivative work containing translated language files based on the original mod.
It does NOT include the original mod itself, which must be downloaded separately.

This resource pack is licensed under the MIT License.
A copy of the MIT License is included in the "LICENSE.txt" file.

(日本語訳)
本リソースパックはオリジナルMODの言語ファイルを翻訳した派生物であり、MOD本体（.jar）は含まれていません。
動作には公式ページからのオリジナルMODの導入が別途必要です。

本リソースパックは MIT License の下で公開されています。
ライセンスの全文は同梱の LICENSE.txt をご確認ください。

■ 注意事項 / Important Notice
・本リソースパック（日本語化ファイル）の使用により生じたいかなる損害についても、制作者（Mine-Tech）および元のMOD制作者は一切の責任を負いません。
・本リソースパックは非公式なものであり、個別のサポートやアップデートの義務は負いません。
・本リソースパックに関する質問や不具合報告を、元のMOD制作者へ送ることは絶対におやめください。